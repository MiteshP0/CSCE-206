#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void swapArray(int [], int);

int main()
{

	const int SIZE = 100;
	int array[SIZE];
	
	srand (time(0)); // seed random number generator
	
	cout << endl; // for spacing
	
	cout <<"The elements in the initial array are shown below: \n";
	cout << "_____________________________________\n";
	//prints array with numbers between 0-1000
	for(int index = 0; index < SIZE; index++)
	{
		array[index] = (rand()%1001); //%1001 prints out numbers 0-1000
		cout << array[index] << " "; // print out the random numbers
	}
	cout << endl << endl; // for spacing
	
	swapArray(array, SIZE);
	
return 0;

}

void swapArray(int initialArray[], int size)
{
	int *firstHalf;
	firstHalf = initialArray;
	for(int index = 0; index < (size / 2); index++)
		*(firstHalf + index) = initialArray[index];

		
	int *lastHalf;
	lastHalf = initialArray;
	for(int index = (size / 2); index < size; index++)
		*(lastHalf + index) = initialArray[index];
		
	cout << "The swapped elements are :\n";
	cout << "_____________________________\n";
		
	for(int index = (size / 2); index < size; index++)
		cout << *(lastHalf + index) << " ";
		
	for(int index = 0; index < (size/2); index++)
		cout << *(firstHalf + index) << " ";
	
}