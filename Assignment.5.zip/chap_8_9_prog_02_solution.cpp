#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
void selectionSortDescending(int [], int);
void selectionSortAscending(int [], int);
void showArray(int [], int);


int main()
{
	const int SIZE = 100;
	int array[SIZE];
	
	srand (time(0)); // seed random number generator
	
	cout << endl; // for spacing
	
	cout <<"The unsorted array is shown below: \n";
	cout << "_____________________________________\n";
	//prints array with numbers between 0-1000
	for(int index = 0; index < SIZE; index++)
	{
		array[index] = (rand()%1001); //%1001 prints out numbers 0-1000
		cout << array[index] << " "; // print out the random numbers
	}
	cout << endl << endl; // for spacing
	
	// selection sort in descending order
	selectionSortDescending(array, SIZE);
	
	cout << "Descending order\n";
	cout << "____________________\n";
	// show descending array
	showArray(array, SIZE);
	
	cout << endl << endl; // for spacing
	
	// selection sort in ascending order	
	selectionSortAscending(array, SIZE);
	
	cout << "Ascending order\n";
	cout << "____________________\n";
	// show ascending array
	showArray(array, SIZE);
	


return 0;
}

void selectionSortDescending(int sortedArray[], int size)
{
	int startScan;
	int minIndex;
	int minValue;
	for(startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = sortedArray[startScan];
		for(int index = startScan + 1; index < size; index++)
		{
			if(sortedArray[index] > minValue)
			{
				minValue = sortedArray[index];
				minIndex = index;
			}
		}
		
		sortedArray[minIndex] = sortedArray[startScan];
		sortedArray[startScan] = minValue;
	}

	
}

void selectionSortAscending(int sortedArray[], int size)
{
	int startScan;
	int minIndex;
	int minValue;
	for(startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = sortedArray[startScan];
		for(int index = startScan + 1; index < size; index++)
		{
			if(sortedArray[index] < minValue)
			{
				minValue = sortedArray[index];
				minIndex = index;
			}
		}
		
		sortedArray[minIndex] = sortedArray[startScan];
		sortedArray[startScan] = minValue;
	}
}

void showArray(int shownArray[], int size)
{
	for(int index = 0; index < size; index++)
		cout << shownArray[index] << " ";
}