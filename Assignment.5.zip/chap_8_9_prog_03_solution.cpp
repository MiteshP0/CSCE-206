#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

void selectionSortAscending(int [], int);
void showArray(int [], int);
int binarySearch(int [], int , int);

int main()
{
	const int SIZE = 100;
	int array[SIZE];
	
	srand (time(0)); // seed random number generator
	
	cout << endl; // for spacing
	
	cout <<"The unsorted array is shown below: \n";
	cout << "_____________________________________\n";
	//prints array with numbers between 0-1000
	for(int index = 0; index < SIZE; index++)
	{
		array[index] = (rand()%1001); //%1001 prints out numbers 0-1000
		cout << array[index] << " "; // print out the random numbers
	}
	cout << endl << endl; // for spacing

	// selection sort in ascending order	
	selectionSortAscending(array, SIZE);
	
	cout << "Ascending order\n";
	cout << "____________________\n";
	// show ascending array
	showArray(array, SIZE);
	
	cout << endl << endl; // for spacing
	
	cout << "Now I will perform a binary search to find if the last three digits of my UIN (210) are in the ascending order array\n";
	cout << "______________________________________________________________________________________________________________\n";
	
	// perform binary search
	int result;
	result = binarySearch(array, SIZE, 210);
	if(result == -1)
		cout << "Could not find my UIN. Chances of finding are low. Entering part 3 of the problem!! \n\n";
	else
		cout <<"WOW, found the value of " << array[result] << " in element " << result << " of the array!\n";

	cout << "Now I will perform a binary search by letting you enter the value you want to search for.\n";
	cout << "______________________________________________________________________________________________________________\n";
	
	int value;
	cout << "Enter a value in the range between 0-1000\n";
	cin >> value;
	while(value < 0 || value > 1000)
	{
		cout << "ERROR. You entered a value not in the range. Try again!\n";
		cout << "Enter a value in the range between 0-1000\n";
		cin >> value;
	}
	
	int userResult;
	userResult = binarySearch(array, SIZE, value);
	if(userResult == -1)
		cout << "Could not find value. Chances of finding are low.\n";
	else
		cout <<"WOW, found the value of " << array[userResult] << " in element " << userResult << " of the array!\n";
	
			
	
	
return 0;
}


void selectionSortAscending(int sortedArray[], int size)
{
	int startScan;
	int minIndex;
	int minValue;
	for(startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = sortedArray[startScan];
		for(int index = startScan + 1; index < size; index++)
		{
			if(sortedArray[index] < minValue)
			{
				minValue = sortedArray[index];
				minIndex = index;
			}
		}
		
		sortedArray[minIndex] = sortedArray[startScan];
		sortedArray[startScan] = minValue;
	}
}

void showArray(int shownArray[], int size)
{
	for(int index = 0; index < size; index++)
		cout << shownArray[index] << " ";
}

int binarySearch(int binaryArray[], int size, int value)
{
	int first = 0;
	int last = size - 1;
	int middle;
	int position = -1;
	bool found = false;
	
	while(!found && first <= last)
	{
		middle = (first + last) / 2;
		if (binaryArray[middle] == value)
		{
			found = true;
			position = middle;
		}
		else if (binaryArray[middle] > value)
			last = middle - 1;
		else 
			first = middle + 1;
	}
	return position;
}