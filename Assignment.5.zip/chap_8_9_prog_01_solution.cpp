#include <iostream>
#include <ctime> // for random number generator.
#include <cstdlib> // for ran and srand
#include <vector>
using namespace std;

int main()
{
	const int SIZE = 100;
	int array[SIZE];
	int primeArray[25] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97}; //prime numbers up to 100


	srand (time(0)); // seed random number generator
	
	cout << endl; // for spacing
	
	//prints array with numbers between 0-1000
	for(int index = 0; index < SIZE; index++)
	{
		array[index] = (rand()%1000); //%1001 prints out numbers 0-1000
		cout << array[index] << " "; // print out the random numbers
	}
	
	cout << endl << endl; // for spacing
	
	
	// code below performs linear search using nested for loops. testing value of array then testing that value and comparing it to the values in prime array
	// after testing value of array. it moves onto the next element, just like a linear search is suppose to.
	int subscript;
	int count;
	vector<int> newPrimeVector;
	
	for(count = 0; count < SIZE; count++ )
	{
		for(subscript = 0; subscript < 25; subscript++)
		{
			if(array[count] == primeArray[subscript])
			{
				newPrimeVector.push_back(array[count]);
			
			}
		}
		
	}
	
		// if the vector is empty then no prime numbers were found
	if(newPrimeVector.empty())
		cout << "No prime numbers up to 100 were detected! Please run the program again.\n";
		// otherwise display the prime numbers found	
	else
	{
		cout <<"The prime numbers less than 100 that are in the array are: ";
		for(int count = 0; count < newPrimeVector.size(); count++)
			cout << newPrimeVector[count] << " ";
	}
	
	cout << endl << endl;
	
	
	
	
	
	//CODE NOT RIGHT
	// now this code is to find the multiples of the user entered number
	int number;
	cout <<"Enter a number greater than 0 and less than 100, and I will find the multiples of that number. BUT only the multiples that are located in the array\n";
	cin >> number;
	while(number < 0 || number > 100)
	{		
		cout << "The number you entered was not in the specific range. Try Again!\n";
		cin >> number;
	}
	//int finder;
	//for(finder = 0; finder < SIZE; finder++ )
	//{
	//	if(array[finder] == number)
	//	{
	//		cout << "The multiples of " << number << " are: \n";
	//		break;
	//		
	//	}	
	//}
	
	cout << endl;
	cout << "Now I will locate the multiples of the number you entered that are in the array ONLY.\n";	
	
	// below code finds multiples and puts them in vector
	vector<int> multiple;
	//multiples of 1 and the number entered will always be a multiple
	multiple.push_back(1);
	multiple.push_back(number);
	
	for(int counter = 2; counter < number/counter ; counter++ )
	{
		
		if(number % counter == 0)
		{
			multiple.push_back(counter);
			multiple.push_back((number/counter));
		}	
	}
	
	//for(int index = 0; index < multiple.size(); index++)
		//cout << multiple[index] << " ";
		
	// search for multiple
	cout <<"The multiples is/are: ";
	for(int count = 0; count < SIZE; count++ )
	{
		for(int subscript = 0; subscript < multiple.size(); subscript++)
		{
			if(array[count] == multiple[subscript])
			{
				cout << array[count] << " ";
			
			}
			
		}
		
	}
	
	cout << endl;
	
return 0;
}