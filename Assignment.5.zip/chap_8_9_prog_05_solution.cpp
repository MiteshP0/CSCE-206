#include <iostream>
#include <string>
using namespace std;

int main()
{
	string firstString;
	string secondString;
	char *thirdString;
	
	//ask user for string
	cout <<"Enter a string!\n";
	getline(cin,firstString);
	
	// ask for another string
	cout <<"Enter another string!\n";
	getline(cin,secondString);
	
	int size = firstString.length() + secondString.length();	
	
	thirdString = new char[size];  // holds array size proper to the lengths of the strings added above
	
	int sizeFirst = firstString.size(); //holds size of first string (bytes)
	int sizeSecond = secondString.size(); // holds size of second string (bytes)
	
	
	
	cout << endl << endl;
	// the below code outputs the necessary items for the problem!
	
	
	cout << firstString << endl;
	cout << secondString << endl;	
	
	
	
	
	for(int index = 0; index < sizeFirst; index++)
	{
		thirdString[index] = firstString[index];	
		cout << thirdString[index];
	}
	
	cout <<" ";
	
	for(int index = 0; index < sizeSecond; index++)
	{
		thirdString[index] = secondString[index];	
		cout << thirdString[index];
	}
	cout <<".";

return 0;
}