#include <iostream>
#include <cmath>
#include <cstdlib>
using namespace std;


int main()
{
	double sum = 0;
	int numberInput;
	double average;
	cout <<"Enter a number, and I will compute the average of 1 through the number your entered, the even number average, and the odd number average.\n";
	cin >> numberInput;
	 
	 // for loop to calculate the sum
	for(int count = 1; count <= numberInput; count++)
	{
	
		sum += count;
	
	}
	average = sum / numberInput;
	cout << "The average of the numbers from 1 through " << numberInput << " is " << average << endl;
	
	
	
	
	int sumEven = 0;
	int averageEven; 	
	for(int count = 2; count <= numberInput; count+=2)
	{
	
		sumEven += count;
	
	}
	if(numberInput % 2 == 0)
	{
		averageEven = sumEven / (numberInput / 2);
		cout << "The average of the even numbers from 1 through " << numberInput << " is " << averageEven << endl;
	}
	else
	{
		averageEven = sumEven / static_cast<int>(numberInput / 2);
		cout << "The average of the even numbers from 1 through " << numberInput << " is " << averageEven << endl;
	}
	
	
	
	
	int sumOdd = 0;
	int averageOdd; 	
	for(int count = 1; count <= numberInput; count+=2)
	{
	
		sumOdd += count;
	
	}
	averageOdd = sumOdd / (sqrt(sumOdd));
	cout << "The average of the odd numbers from 1 through " <<numberInput << " is " << averageOdd << endl;
	
	
	// conditions for determining highest average and lowest
	if(average == averageEven && average == averageOdd && averageEven == averageOdd)
	{
		cout << "All three of the averages are equal" << endl;
		exit(0);
	}
	if(average == averageEven || average == averageOdd || averageEven == averageOdd)
	{
		cout << "Two of the averages are equal" << endl;
	}	
	if(average > averageEven && average > averageOdd)
	{
		cout << "The highest average is " << average << endl;
	}
	if(average < averageEven && average < averageOdd)
	{
		cout << "The lowest average is " << average << endl;
	}
	
	
	
	

	if(averageEven > average && averageEven > averageOdd)
	{
		cout << "The highest average is " << averageEven << endl;
	}
	if(averageEven < average && averageEven < averageOdd)
	{
		cout << "The lowest average is " << averageEven << endl;
	}



	if(averageOdd > average && averageOdd > averageEven)
	{
		cout << "The highest average is " << averageOdd << endl;	
	}
	if(averageOdd < average && averageOdd < averageEven)
	{
		cout << "The lowest average is " << averageOdd << endl;	
	}


}