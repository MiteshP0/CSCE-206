#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	//Constants for the multiples
	const int multipleOne= 1;
	const int multipleTwo= 2;
	const int multipleThree= 3;
	const int multipleFour= 4;
	const int multipleFive= 5;
	const int multipleSix= 6;
	const int multipleSeven= 7;
	
	int finalAverage; //to hold the final average of all the multiples combined
	
	ofstream outputFile;
	outputFile.open("numbers.txt"); //Creates numbers file
	
	//Write multiples of 1 up to 100 onto the file
	int multipleOne_Accum = 0; //Accumulator for multiple ones
	outputFile <<"The multiples of 1 up to 100 are :\n";
	for(int multipleOne_count = 0; multipleOne_count <= 100; multipleOne_count++)
	{
		outputFile << multipleOne * multipleOne_count << endl;
		multipleOne_Accum += multipleOne * multipleOne_count;
	}
	
	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 2 up to 100 onto the file
	int multipleTwo_Accum = 0; //Accumulator for multiple two
	outputFile <<"The multiples of 2 up to 100 are :\n";
	for(int multipleTwo_count = 0; multipleTwo_count <= 100; multipleTwo_count++)
	{
		outputFile << multipleTwo * multipleTwo_count << endl;
		multipleTwo_Accum += multipleTwo * multipleTwo_count;
	}

	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 3 up to 100 onto the file
	int multipleThree_Accum = 0; //Accumulator for multiple three
	outputFile <<"The multiples of 3 up to 100 are :\n";
	for(int multipleThree_count = 0; multipleThree_count <= 100; multipleThree_count++)
	{
		outputFile << multipleThree * multipleThree_count << endl;
		multipleThree_Accum += multipleThree * multipleThree_count;
	}
	
	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 4 up to 100 onto the file
	int multipleFour_Accum = 0; //Accumulator for multiple four
	outputFile <<"The multiples of 4 up to 100 are :\n";
	for(int multipleFour_count = 0; multipleFour_count <= 100; multipleFour_count++)
	{
		outputFile << multipleFour * multipleFour_count << endl;
		multipleFour_Accum += multipleFour * multipleFour_count;
	}
	
	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 5 up to 100 onto the file
	int multipleFive_Accum = 0; //Accumulator for multiple five
	outputFile <<"The multiples of 5 up to 100 are :\n";
	for(int multipleFive_count = 0; multipleFive_count <= 100; multipleFive_count++)
	{
		outputFile << multipleFive * multipleFive_count << endl;
		multipleFive_Accum += multipleFive * multipleFive_count;
	}
	
	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 6 up to 100 onto the file
	int multipleSix_Accum = 0; //Accumulator for multiple six
	outputFile <<"The multiples of 6 up to 100 are :\n";
	for(int multipleSix_count = 0; multipleSix_count <= 100; multipleSix_count++)
	{
		outputFile << multipleSix * multipleSix_count << endl;
		multipleSix_Accum += multipleSix * multipleSix_count;
	}
	
	outputFile << endl; // Used to space out for clear reading
	
	//Write multiples of 7 up to 100 onto the file
	int multipleSeven_Accum = 0; //Accumulator for multiple six
	outputFile <<"The multiples of 7 up to 100 are :\n";
	for(int multipleSeven_count = 0; multipleSeven_count <= 100; multipleSeven_count++)
	{
		outputFile << multipleSeven * multipleSeven_count << endl;
		multipleSeven_Accum += multipleSeven * multipleSeven_count;
	}
	
	finalAverage = (multipleOne_Accum + multipleTwo_Accum + multipleThree_Accum + multipleFour_Accum + multipleFive_Accum + multipleSix_Accum + multipleSeven_Accum) / 700; //divide by 700 because all numbers in the final is 700
	
	outputFile << "THE FINAL AVERAGE OF ALL 700 NUMBERS IN THIS FILE IS " << finalAverage << ".\n";
	
	cout<< "Go check the numbers file dude!!\n";	
	
	outputFile.close();



}
