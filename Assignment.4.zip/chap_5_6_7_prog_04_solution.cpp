#include <iostream>
#include <iomanip>
using namespace std;

	// global constants
	const int rowSize = 5;
	const int colSize = 5;
	
void showArray(const int[][colSize], int); //function prototype
	
int main()
{

	//contains numbers 1-25
	int array1[rowSize][colSize] = {{1, 2, 3, 4, 5},
									{6, 7, 8, 9, 10},
									{11, 12, 13, 14, 15},
									{16, 17, 18, 19, 20},
									{21, 22, 23, 24, 25}};
	//contains numbers 26-50								 
	int array2[rowSize][colSize] = {{26, 27, 28, 29, 30},
									{31, 32, 33, 34, 35},
									{36, 37, 38, 39, 40},
									{41, 42, 43, 44, 45},
									{46, 47, 48, 49, 50}};
	//should end up containing product of the array 1 and array 2
	int array3[rowSize][colSize];
	// puts products of the two arrays in array 3
	for(int row = 0; row < 5; row++)
	{
	
		for(int col = 0; col < 5; col++)
		{
			array3[row][col] = (array1[row][col] * array2[row][col]); 
		
		}
	
	}
	//shows the contents of all three arrays
	cout << "The contents of array 1 are: \n"; 
	showArray(array1, rowSize);
	cout << endl;
	
	cout << "The contents of array 2 are: \n"; 
	showArray(array2, rowSize);
	cout << endl;
	
	cout << "The contents of array 3 are: \n"; 
	showArray(array3, rowSize);
	cout << endl;

}


void showArray(const int array[][colSize], int rows)
{
	for(int x = 0; x < 5; x++)
	{
		for(int y = 0; y < 5; y++)
		{
			cout << setw(4) << array[x][y] << " ";
		
		}
	
		cout << endl;
	}
}