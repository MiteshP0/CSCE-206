#include <iostream>
using namespace std;

	//Global Constants
	const int basePoint_Monday = 8;
	const int basePoint_Tuesday= 13;
	const int basePoint_Wednesday = 15;
	const int basePoint_Thursday = -5;
	const int basePoint_Friday = 20;
	const int basePoint_Saturday= -3;
	const int basePoint_Sunday = 9;
	
	//Global Variables /Accumulators 
	int totalMonday = 0;
	int totalTuesday = 0;
	int totalWednesday = 0;
	int totalThursday = 0;
	int totalFriday = 0;
	int totalSaturday = 0;
	int totalSunday = 0;
	
	//Function prototypes	
	void MondayCalculation();
	void TuesdayCalculation();
	void WednesdayCalculation();
	void ThursdayCalculation();
	void FridayCalculation();
	void SaturdayCalculation();
	void SundayCalculation();
	void FinalTotal();
	
int main()
{
	
	// All the function calls for this program
	MondayCalculation();
	TuesdayCalculation();
	WednesdayCalculation();
	ThursdayCalculation();
	FridayCalculation();
	SaturdayCalculation();
	SundayCalculation();
	FinalTotal();
}


void MondayCalculation()
{
	int milesRan_Monday;
	//int totalMonday = 0; //Accumulator
	cout << "How many miles did the jogger run on Monday?\n";
	cin >> milesRan_Monday;
	
	for(int count = 1; count <= milesRan_Monday; count++)
	{
		totalMonday += count * basePoint_Monday; 
	}
	cout << "The total points earned on Monday is " << totalMonday <<".\n";
}

void TuesdayCalculation()
{
	int milesRan_Tuesday;
	//int totalTuesday = 0; //Accumulator
	cout << "How many miles did the jogger run on Tuesday?\n";
	cin >> milesRan_Tuesday;
	
	for(int count = 1; count <= milesRan_Tuesday; count++)
	{
		totalTuesday += count * basePoint_Tuesday; 
	}
	cout << "The total points earned on Tuesday is " << totalTuesday <<".\n";
}

void WednesdayCalculation()
{
	int milesRan_Wednesday;
	//int totalWednesday = 0; //Accumulator
	cout << "How many miles did the jogger run on Wednesday?\n";
	cin >> milesRan_Wednesday;
	
	for(int count = 1; count <= milesRan_Wednesday; count++)
	{
		totalWednesday += count * basePoint_Wednesday; 
	}
	cout << "The total points earned on Wednesday is " << totalWednesday <<".\n";
}

void ThursdayCalculation()
{
	int milesRan_Thursday;
	//int totalThursday = 0; //Accumulator
	cout << "How many miles did the jogger run on Thursday?\n";
	cin >> milesRan_Thursday;
	
	for(int count = 1; count <= milesRan_Thursday; count++)
	{
		totalThursday += count * basePoint_Thursday; 
	}
	cout << "The total points earned on Thursday is " << totalThursday <<".\n";
}

void FridayCalculation()
{
	int milesRan_Friday;
	//int totalFriday = 0; //Accumulator
	cout << "How many miles did the jogger run on Friday?\n";
	cin >> milesRan_Friday;
	
	for(int count = 1; count <= milesRan_Friday; count++)
	{
		totalFriday += count * basePoint_Friday; 
	}
	cout << "The total points earned on Friday is " << totalFriday <<".\n";
}

void SaturdayCalculation()
{
	int milesRan_Saturday;
	//int totalSaturday = 0; //Accumulator
	cout << "How many miles did the jogger run on Saturday?\n";
	cin >> milesRan_Saturday;
	
	for(int count = 1; count <= milesRan_Saturday; count++)
	{
		totalSaturday += count * basePoint_Saturday; 
	}
	cout << "The total points earned on Saturday is " << totalSaturday <<".\n";
}

void SundayCalculation()
{
	int milesRan_Sunday;
	//int totalSunday = 0; //Accumulator
	cout << "How many miles did the jogger run on Sunday?\n";
	cin >> milesRan_Sunday;
	
	for(int count = 1; count <= milesRan_Sunday; count++)
	{
		totalSunday += count * basePoint_Sunday; 
	}
	cout << "The total points earned on Sunday is " << totalSunday <<".\n";
}

void FinalTotal()
{
	int finalTotal = totalMonday + totalTuesday + totalWednesday + totalThursday + totalFriday + totalSaturday + totalSunday;
	cout << "The total points earned throughout the whole week is " << finalTotal << ".\n";
}