#include<iostream>
#include<cstdlib>
using namespace std;


// function prototypes

void add(int = 10, int = 20);
void add(double, double);
void add(char, char);
void add(int, double);
void add(double, int);
void add(int, char);
void add(char, int);

int main()
{
	int choice;
	char answer;
	
	cout << "This program will display the sum of the following data types below after you enter the appropriate values\n\n";
	
	do
	{
	//displays menu
	cout <<"\t" << "1. " << "int, int\n\n";
	cout <<"\t" << "2. " << "float, float\n\n";
	cout <<"\t" << "3. " << "char, char\n\n";
	cout <<"\t" << "4. " << "int, float\n\n";
	cout <<"\t" << "5. " << "float, int\n\n";
	cout <<"\t" << "6. " << "int, char\n\n";
	cout <<"\t" << "7. " << "char, int\n\n";
	cout <<"\t" << "8. " << "Default Arguments\n\n";
	cout <<"\t" << "9. " << "Exit\n\n";
	
	cout << "Enter your choice (1-9)\n";
	cin >> choice;
	
	
	if(choice == 1)
	{
		int integar1, integar2;
		cout <<"Enter two integar values separated by a space\n";
		cin >> integar1 >> integar2;
		add(integar1, integar2);
	
	}
	
	else if(choice == 2)
	{
		double double1, double2;
		cout << "Enter two floating point values separated by a space.\n";
		cin >> double1 >> double2;
		add(double1, double2);
	}
	else if(choice == 3)
	{
		char char1, char2;
		cout <<"Enter two character values (A-Z) separated by a space. I will calculate sum of ASCII value\n";
		cin >> char1 >> char2;
		add(char1, char2);
	
	}
	else if (choice == 4)
	{
		int integar1;
		double double2;
		cout << "Enter an integar value and a floating point value separated by a space\n";
		cin >> integar1 >> double2;
		add(integar1, double2);
			
	}
	else if (choice == 5)
	{
		double double1;
		int integar2;
		cout << "Enter an floating point value and a integar value separated by a space\n";
		cin >> double1 >> integar2;
		add(double1, integar2);	
	
	}
	else if (choice == 6)
	{
		int integar1;
		char char2;
		cout <<"Enter a integar value and a character(A-Z) separated by a space\n";
		cin >> integar1 >> char2;
		add(integar1, char2);
	
	}
	else if(choice == 7)
	{
		char char1;
		int integar2;
		cout << "Enter a character(A-Z) and a integar separated by a space\n";
		cin >> char1 >> integar2;
		add(char1, integar2);
	
	}
	else if(choice == 8)
	{
		add(); // parameter with default arguments
	}
	else if(choice ==9)
	{
		cout << "Exiting program now......\n";	
		exit(0);
	}
	
	cout <<"Do you want to continue (Y/N)?\n";
	cin >> answer;
	} while(answer == 'y' || answer == 'Y' );
	
}

















	//FUNCTION DEFINITIONS 
void add(int param1, int param2)
{
	int result = param1 + param2;
	cout << "The result is " << result << "." << endl;

}


void add(double number1, double number2)
{

	double doubleResult = number1 + number2;
	cout <<"The result is " << doubleResult << "." << endl;
	
}

void add(char number1, char number2)
{

	int charResult = number1 + number2;
	cout <<"The result is " << charResult << "." << endl;
	cout <<"This is the result of the two ASCII values associated with the character you entered\n";
}

void add(int number1, double number2)
{

	// chars automatically promoted to int
	// data type ranking:
	// double
	// float
	// int 
	// when operator works with two diff value type the lower data type is promoted to the higher ranking value
	
	double int_doubleResult = number1 + number2;
	cout << "The result is " << int_doubleResult << "." << endl;
	cout <<"NOTE: since we are adding an int and a float, the final result will end up as a float.\n";
}

void add(double number1, int number2)
{
	
	double double_intResult = number1 + number2;
	cout << "The result is " << double_intResult << "." << endl;
	cout <<"NOTE: since we are adding an float and a int, the final result will end up as a float.\n";
}

void add(int number1, char number2)
{
	
	int int_charResult = number1 + number2;
	cout << "The result is " << int_charResult << "." << endl;
	cout <<"NOTE: since we are adding an int and a char, the final result will end up as a int.\n";
}

void add(char number1, int number2)
{
	
	int char_intResult = number1 + number2;
	cout << "The result is " << char_intResult << "." << endl;
	cout <<"NOTE: since we are adding an char and a int, the final result will end up as a int.\n";
}

